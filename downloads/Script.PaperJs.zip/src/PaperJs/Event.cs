﻿namespace PaperJs
{
    /// <summary>
    /// Base class for Paper.js events
    /// </summary>
    public class Event { }
}