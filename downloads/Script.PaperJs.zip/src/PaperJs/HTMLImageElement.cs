﻿namespace PaperJs
{
    /// <summary>
    /// DOM representation of a HTML img element.
    /// </summary>
    public class HTMLImageElement { }
}